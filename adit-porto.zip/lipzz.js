function ketikMesinTik(elemen, teks, delay) {
  let i = 0;
  function ketik() {
    if (i < teks.length) {
      elemen.innerHTML += teks.charAt(i);
      i++;
      setTimeout(ketik, delay);
    }
  }
  ketik();
}

// Contoh penggunaan
const elemenTeks = document.getElementById("teks-mesin-tik");
const teks = "Halo, ini adalah contoh teks yang diketik seperti mesin tik.";
ketikMesinTik(elemenTeks, teks, 100); // Delay 100ms antar karakter