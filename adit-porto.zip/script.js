// KODE PORTOFOLIO BY LIPPWANGSAFF
// KODE PORTOFOLIO BY LIPPWANGSAFF

// JANGAN HAPUS WM !!!
// JANGAN HAPUS WM !!!
const audio = document.getElementById("audio");
const audioSource = document.getElementById("audioSource");
const audioButton = document.getElementById("audioButton");
const playIcon = document.getElementById("playIcon");
const pauseIcon = document.getElementById("pauseIcon");
const prevButton = document.getElementById("prevButton");
const nextButton = document.getElementById("nextButton");

// Daftar lagu
const playlist = [
    "https://files.catbox.moe/czwqq3.mp3",
    "https://files.catbox.moe/1ldq3p.mp3",
    "https://files.catbox.moe/eibelh.mp3",
    "https://files.catbox.moe/uh6yrh.mp3",
    "https://files.catbox.moe/m0zd7h.mp3",
    "https://files.catbox.moe/klu274.mp3",
    "https://files.catbox.moe/u2vvzk.mp3",
    "https://files.catbox.moe/xybcqz.mp3",
    "https://files.catbox.moe/wtjym8.mp3",
    "https://files.catbox.moe/x7u9qw.mp3"
];

let currentTrack = 0;

// Fungsi Play/Pause
audioButton.addEventListener("click", () => {
    if (audio.paused) {
        audio.play();
        playIcon.style.display = "none";
        pauseIcon.style.display = "block";
    } else {
        audio.pause();
        playIcon.style.display = "block";
        pauseIcon.style.display = "none";
    }
});

// Fungsi Ganti Lagu
function changeTrack(index) {
    if (index < 0) {
        currentTrack = playlist.length - 1; // Jika di awal, putar lagu terakhir
    } else if (index >= playlist.length) {
        currentTrack = 0; // Jika di akhir, kembali ke lagu pertama
    } else {
        currentTrack = index;
    }

    audioSource.src = playlist[currentTrack];
    audio.load();
    audio.play();
    playIcon.style.display = "none";
    pauseIcon.style.display = "block";
}

// Tombol Next
nextButton.addEventListener("click", () => {
    changeTrack(currentTrack + 1);
});

// Tombol Prev
prevButton.addEventListener("click", () => {
    changeTrack(currentTrack - 1);
});

// Auto-Play Next Song Ketika Lagu Selesai
audio.addEventListener("ended", () => {
    changeTrack(currentTrack + 1);
});


function toggleMenu() {
    var menu = document.querySelector(".nav-menu");
    menu.classList.toggle("show");
}

function closeMenu() {
    var menu = document.querySelector(".nav-menu");
    menu.classList.remove("show");
}

document.addEventListener("click", function (event) {
    var menu = document.querySelector(".nav-menu");
    var hamburger = document.querySelector(".hamburger");

    if (!menu.contains(event.target) && !hamburger.contains(event.target)) {
        menu.classList.remove("show");
    }
});

function showModal(skill) {
    document.getElementById('modal-' + skill).style.display = 'block';
}

function closeModal(skill) {
    document.getElementById(`modal-${skill}`).style.display = 'none';
}

function showPasswordPrompt(skill) {
    document.getElementById("password-modal").style.display = "block";
    window.passwordSkill = skill;
    document.getElementById("password-error-container").style.display = "none";
}

function checkPassword(skill) {
    const password = document.getElementById("password-input").value;
    const passwordErrorContainer = document.getElementById("password-error-container");
    if (password === "LipWangSapp") {
        document.getElementById("password-modal").style.display = "none";
        document.getElementById(`modal-${window.passwordSkill}`).style.display = "block";
        passwordErrorContainer.style.display = "none";
    } else {
        passwordErrorContainer.style.display = "block";
    }
}

function sendMessage() {
    const userInput = document.getElementById('user-input');
    const message = userInput.value.trim();
    if (message) {
        appendMessage('user', message);
        userInput.value = '';
        getAiResponse(message);
    }
}

function appendMessage(sender, message) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', `${sender}-message`);
    messageDiv.textContent = message;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function getAiResponse(query) {
    fetch('https://www.blackbox.ai/json?q=' + encodeURIComponent(query))
        .then(response => response.json())
        .then(data => {
            if (data && data.text) {
                // Menampilkan teks jawaban dari Blackbox AI.
                appendMessage('ai', data.text);
            } else {
                appendMessage('ai', 'Tidak ada hasil ditemukan atau format respons tidak sesuai.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            appendMessage('ai', 'Terjadi kesalahan dalam pencarian.');
        });
}

let count = 0;
const dzikirList = [
    { latin: "Astaghfirullah al-'adzim", arabic: "أستغفر الله العظيم" },
    { latin: "Subhanallah", arabic: "سبحان الله" },
    { latin: "Alhamdulillah", arabic: "الحمد لله" },
    { latin: "La ilaha illallah", arabic: "لا إله إلا الله" },
    { latin: "Allahu Akbar", arabic: "الله أكبر" },
    { latin: "Hauqalah", arabic: "لا حول ولا قوة إلا بالله" }
];
let currentDzikirIndex = 0;

function incrementCount() {
    count++;
    document.getElementById('count').innerText = count;
}

function gantiDzikir() {
    currentDzikirIndex = (currentDzikirIndex + 1) % dzikirList.length;
    document.getElementById('dzikir').innerText = dzikirList[currentDzikirIndex].latin;
    document.getElementById('arabic').innerText = dzikirList[currentDzikirIndex].arabic;
    resetCount();
}

function resetCount() {
    count = 0;
    document.getElementById('count').innerText = count;
}

function showModal(modalId) {
    document.getElementById('modal-' + modalId).style.display = "block";
}

function closeModal(modalId) {
    document.getElementById('modal-' + modalId).style.display = "none";
}

window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = "none";
    }
};

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
        e.preventDefault();

        document.querySelector(this.getAttribute("href")).scrollIntoView({
            behavior: "smooth"
        });
    });
});